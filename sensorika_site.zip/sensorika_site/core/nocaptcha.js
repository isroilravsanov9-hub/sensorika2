(function () {
  // Sahifadagi captcha oynalari/belgilarini olib tashlaydi (yangi chiqqanlarini ham).
  var SEL = [
    ".g-recaptcha", ".grecaptcha-badge", ".h-captcha", ".cf-turnstile", ".smart-captcha", "[data-sitekey]",
    'iframe[src*="recaptcha"]', 'iframe[src*="hcaptcha"]', 'iframe[src*="turnstile"]',
    'iframe[src*="smartcaptcha"]', 'iframe[src*="challenges.cloudflare.com"]',
    '[id*="captcha" i]', '[class*="captcha" i]', 'img[src*="antibot"]', 'img[src*="sec_code"]'
  ].join(",");

  function popupOf(el) {
    for (var n = el.parentElement; n && n !== document.body; n = n.parentElement) {
      var tokens = ((n.className && n.className.toString()) || "").toLowerCase().split(/\s+/);
      if (tokens.indexOf("modal") >= 0 || tokens.indexOf("popup") >= 0 || tokens.indexOf("mfp-wrap") >= 0 ||
          getComputedStyle(n).position === "fixed") return n;
    }
    return null;
  }
  function clean() {
    var found = document.querySelectorAll(SEL);
    for (var i = 0; i < found.length; i++) {
      var el = found[i];
      if (!el.isConnected) continue;
      var pop = popupOf(el);
      (pop || el).remove();
      if (pop) {
        [].forEach.call(document.querySelectorAll(".modal-backdrop,.mfp-bg"), function (b) { b.remove(); });
        document.body.classList.remove("modal-open");
        document.body.style.overflow = "";
        document.body.style.paddingRight = "";
      }
    }
  }
  clean();
  new MutationObserver(clean).observe(document.documentElement, { childList: true, subtree: true });
})();
