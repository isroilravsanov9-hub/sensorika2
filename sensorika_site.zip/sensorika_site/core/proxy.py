"""Asl sayt (sensorika.academy) sahifalarini shu saytning o'zida ochib beradi.

Menyudagi /blog/courses-toshkent/, /blog/courses-navoiy/, /blog/students/... kabi
havolalar Django'da yo'q edi (404 berardi). Endi ular shu yerdan o'tadi.
"""
import re
import urllib.error
import urllib.request

from pathlib import Path

from django.core.cache import cache
from django.http import Http404, HttpResponse, HttpResponseRedirect

ORIGIN = "https://sensorika.academy"
MAX_PAGES = 20  # bitiruvchilar va boshqa ro'yxatlarda faqat 20-sahifagacha

# Faqat shu bo'limlar shu saytning o'zida ochiladi, qolganlari asl saytga o'tkaziladi
ALLOWED = re.compile(
    r"^blog/(courses-toshkent|courses-navoiy|students|topstudent|tashkent-news|navoi-news)(/|$)"
)

PAGE_RE = re.compile(r"/page/(\d+)")
# <a href=".../page/N/">..</a> (ixtiyoriy <li> ichida), oldidagi "…" bilan birga
PAGER_LINK = re.compile(
    r"(?:(?:<li[^>]*>\s*)?(?:<(?:span|div|b|em)[^>]*>\s*)?(?:\.\.\.|…|&hellip;)\s*(?:</(?:span|div|b|em)>\s*)?(?:</li>\s*)?)?"
    r"(?:<li[^>]*>\s*)?<a\b[^>]*?href=[\"']?[^\"'>\s]*?/page/(\d+)/?[\"']?[^>]*>.*?</a>(?:\s*</li>)?",
    re.S | re.I,
)
# ichki havolalar: https://sensorika.academy/... -> /...
INTERNAL_A = re.compile(r"(<a\b[^>]*?\bhref=)([\"']?)" + re.escape(ORIGIN) + r"(?=/)", re.I)


_JS = (Path(__file__).with_name("graduate_photos.js")).read_text(encoding="utf-8")
_NOCAPTCHA = (Path(__file__).with_name("nocaptcha.js")).read_text(encoding="utf-8")
CAPTCHA_SCRIPT = re.compile(
    r"<script\b[^>]*?src=[\"']?[^\"'>\s]*(?:recaptcha|hcaptcha|turnstile|smartcaptcha|captcha\.js)[^>]*>\s*</script>", re.I
)
PHOTO_PATHS = re.compile(r"^blog/(students|topstudent)(/|$)")


def _strip_captcha(html: str) -> str:
    """Captcha skriptlarini olib tashlaydi va captcha oynalarini yashiruvchi skriptni qo'shadi."""
    html = CAPTCHA_SCRIPT.sub("", html)
    tag = f"<script>{_NOCAPTCHA}</script>"
    return html.replace("</body>", tag + "</body>", 1) if "</body>" in html else html + tag


def _add_photos(html: str) -> str:
    """Bitiruvchilar ro'yxatiga: rasmi yo'q kartalarga standart rasm qo'shadi."""
    tag = f"<script>{_JS}</script>"
    return html.replace("</body>", tag + "</body>", 1) if "</body>" in html else html + tag


CONTRACT_RE = re.compile(
    r"<a\b([^>]*?)href=([\"']?)https://smart\.sensorika\.academy/contract-form[\"']?([^>]*)>", re.I
)


def _contract_to_contact(html: str) -> str:
    """"Shartnoma olish" havolasi -> bosh sahifadagi Contact us formasi."""
    def fix(m):
        rest = re.sub(r"\s*target=[\"']?_blank[\"']?", "", m.group(1) + " " + m.group(3))
        return f'<a {rest.strip()} href="/#aloqa">'
    return CONTRACT_RE.sub(fix, html)


def _cap_pages(html: str) -> str:
    return PAGER_LINK.sub(lambda m: "" if int(m.group(1)) > MAX_PAGES else m.group(0), html)


def _fetch(url: str):
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=15) as r:
        ctype = r.headers.get("Content-Type", "")
        if "text/html" not in ctype:
            return None, ctype  # fayl (apk, rasm...) — o'zini asl manzildan olamiz
        charset = r.headers.get_content_charset() or "utf-8"
        return r.read().decode(charset, "replace"), ctype


def mirror(request, path):
    if request.method != "GET":
        raise Http404

    # ruxsat berilmagan sahifa -> asl saytdagi o'sha manzilga o'tkazamiz
    if not ALLOWED.match(path):
        target = f"{ORIGIN}/{path}"
        if request.META.get("QUERY_STRING"):
            target += "?" + request.META["QUERY_STRING"]
        return HttpResponseRedirect(target)

    # 20-sahifadan keyingilarini 20-sahifaga qaytaramiz
    m = PAGE_RE.search(path)
    if m and int(m.group(1)) > MAX_PAGES:
        return HttpResponseRedirect("/" + PAGE_RE.sub(f"/page/{MAX_PAGES}", path, count=1))

    url = f"{ORIGIN}/{path}"
    if request.META.get("QUERY_STRING"):
        url += "?" + request.META["QUERY_STRING"]

    key = "mirror:" + url
    page = cache.get(key)
    if page is None:
        try:
            page, _ = _fetch(url)
        except urllib.error.HTTPError as e:
            if e.code == 404:
                raise Http404("Sahifa topilmadi")
            return HttpResponse(f"Asl sayt xato qaytardi: {e.code}", status=502)
        except Exception as e:
            return HttpResponse(f"Sahifani yuklab bo'lmadi: {e}", status=502)
        if page is None:
            return HttpResponseRedirect(url)
        page = INTERNAL_A.sub(r"\1\2", _cap_pages(_contract_to_contact(page)))
        page = _strip_captcha(page)
        if PHOTO_PATHS.match(path):
            page = _add_photos(page)
        cache.set(key, page, 600)
    return HttpResponse(page, content_type="text/html; charset=utf-8")
