from django.urls import path, re_path
from . import proxy, views

urlpatterns = [
    path("", views.home, name="home"),
    path("contact/", views.contact, name="contact"),
    # qolgan hamma sahifalar (/blog/courses-navoiy/, /blog/students/ ...) asl saytdan
    re_path(r"^(?P<path>.+)$", proxy.mirror),
]
