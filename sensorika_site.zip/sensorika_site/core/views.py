from django import forms
from django.contrib import messages
from django.shortcuts import redirect, render

from . import data, telegram
from .models import Message


class ContactForm(forms.Form):
    name = forms.CharField(
        label="Ismingiz",
        max_length=100,
        widget=forms.TextInput(attrs={"placeholder": "Ismingizni kiriting", "class": "input-field", "required": "required"}),
    )
    phone = forms.CharField(
        label="Telefon raqamingiz",
        max_length=20,
        widget=forms.TextInput(attrs={"placeholder": "+998 90 123 45 67", "class": "input-field", "required": "required"}),
    )
    message = forms.CharField(
        label="Xabar yoki savolingiz",
        max_length=2000,
        widget=forms.Textarea(attrs={"rows": 4, "placeholder": "Qiziqtirgan kursingiz yoki savolingizni yozing...", "class": "input-field textarea-field", "required": "required"}),
    )


def _handle_form(request):
    """Formani qayta ishlaydi. (form, redirect yoki None) qaytaradi."""
    form = ContactForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        d = form.cleaned_data
        Message.objects.create(name=d["name"], phone=d["phone"], text=d["message"])
        ok, err = telegram.send_message(
            f"📩 Yangi murojaat\n\n👤 {d['name']}\n📞 {d['phone']}\n\n💬 {d['message']}"
        )
        if ok:
            messages.success(request, "Xabaringiz yuborildi. Tez orada bog'lanamiz!")
        else:
            messages.error(request, f"Telegramga yuborilmadi: {err}")
        return form, redirect(f"{request.path}#aloqa")
    return form, None


def home(request):
    form, resp = _handle_form(request)
    if resp:
        return resp
    return render(request, "core/home.html", {
        "form": form,
        "graduates": data.GRADUATES,
        "navoiy_news": data.NAVOIY_NEWS,
        "toshkent_courses": data.TOSHKENT_COURSES,
        "toshkent_news": data.TOSHKENT_NEWS,
    })


def contact(request):
    form, resp = _handle_form(request)
    return resp or render(request, "core/contact.html", {"form": form})
