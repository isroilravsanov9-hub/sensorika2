import json
import urllib.error
import urllib.request

from django.conf import settings


def send_message(text: str):
    """Telegram botga xabar yuboradi. (True, "") yoki (False, xato sababi) qaytaradi."""
    token, chat_id = settings.TELEGRAM_BOT_TOKEN, settings.TELEGRAM_CHAT_ID
    if not token or not chat_id:
        return False, ".env da TELEGRAM_BOT_TOKEN yoki TELEGRAM_CHAT_ID yo'q"
    req = urllib.request.Request(
        f"https://api.telegram.org/bot{token}/sendMessage",
        data=json.dumps({"chat_id": chat_id, "text": text}).encode(),
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            return True, ""
    except urllib.error.HTTPError as e:
        try:
            return False, json.load(e).get("description", str(e))
        except Exception:
            return False, str(e)
    except Exception as e:
        return False, str(e)
