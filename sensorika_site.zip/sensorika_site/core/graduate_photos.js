(function () {
  // Rasmi yo'q bitiruvchi kartalariga standart rasm (ism bosh harflari bilan) qo'yadi.
  var links = [].slice.call(document.querySelectorAll("h1 a,h2 a,h3 a,h4 a,h5 a,h6 a")).filter(function (a) {
    return /\/students\/[\w-]+\/\d+-/.test(a.getAttribute("href") || "");
  });
  if (links.length < 2) return;

  function initials(name) {
    var p = name.replace(/[^\p{L}' ]/gu, "").trim().split(/\s+/);
    return ((p[0] || "")[0] || "") + ((p[1] || "")[0] || "");
  }
  function placeholder(name) {
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" width="400" height="400" viewBox="0 0 400 400">' +
      '<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#2563eb"/>' +
      '<stop offset="1" stop-color="#0b1634"/></linearGradient></defs><rect width="400" height="400" fill="url(#g)"/>' +
      '<text x="200" y="240" text-anchor="middle" font-family="Arial,sans-serif" font-size="130" font-weight="700" fill="#fff">' +
      initials(name).toUpperCase() + "</text></svg>";
    return "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
  }
  function cardOf(a) {
    var n = a;
    while (n.parentElement) {
      var p = n.parentElement, c = 0;
      links.forEach(function (l) { if (p.contains(l)) c++; });
      if (c > 1) return n;
      n = p;
    }
    return n;
  }

  var cards = [];
  links.forEach(function (a) {
    var c = cardOf(a);
    if (cards.indexOf(c) < 0) cards.push(c);
  });

  function titleOf(card) {
    return card.querySelector("h1 a,h2 a,h3 a,h4 a,h5 a,h6 a");
  }

  // Rasmi bor birinchi kartadan "rasm bloki" shablonini olamiz
  var media = null, steps = 0, idx = 0;
  cards.forEach(function (c) {
    if (media) return;
    var img = c.querySelector("img"), t = titleOf(c);
    if (!img || !t) return;
    var m = img;
    while (m.parentElement && !m.parentElement.contains(t)) m = m.parentElement;
    if (!m.parentElement) return;
    var box = m.parentElement, n = t, k = 0;
    while (n && n !== box) { n = n.parentElement; k++; }
    if (!n) return;
    media = m; steps = k; idx = [].indexOf.call(box.children, m);
  });

  function setSrc(img, src, name) {
    img.removeAttribute("srcset");
    img.removeAttribute("data-src");
    img.removeAttribute("data-lazy-src");
    img.removeAttribute("loading");
    img.src = src;
    img.alt = name;
  }

  cards.forEach(function (card) {
    var a = titleOf(card);
    var name = a ? a.textContent.trim() : "";
    var img = card.querySelector("img");
    if (!img) {
      var el, box = null;
      if (media && a) {
        box = a;
        for (var i = 0; i < steps && box; i++) box = box.parentElement;
      }
      if (media && box) {
        el = media.cloneNode(true);
        img = el.tagName === "IMG" ? el : el.querySelector("img");
      } else {
        img = document.createElement("img");
        img.style.cssText = "width:100%;aspect-ratio:1/1;object-fit:cover;border-radius:12px;display:block";
        el = img;
        box = card;
        idx = 0;
      }
      setSrc(img, placeholder(name), name);
      box.insertBefore(el, box.children[idx] || null);
    }
    img.onerror = function () { img.onerror = null; setSrc(img, placeholder(name), name); };
  });
})();
